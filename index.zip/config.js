module.export.englishStory="Billy went to hackathons with his friends. His Mother bought the tickets. Billy showed a really good idea in hackathon and won the Hackathon. Billy loved Angel Hack Hackathon."
module.exports.myQuestionAnswers=[
{
	"questionOne": "I am a scientist and politician who served my country as president from 2002 to 2007. was also given a title of India’s Rocket Man. Who am I",
	"type":"general Knowledge",
	"answerone":"2",
	"optionsone":["Rajeev Gandhi","APJ Abdul Kalam","Indira Gandhi","B.R. Ambedkar"]
},
{
	"questionOne": "What is the Name of Hackathon in which Billy Went.",
	"type":"english",
	"answer":"3",
	"optionsone":["Digital Hack","Mobile Hack","Angel Hack","Co Works Hack"],
},
{
	"questionOne": "Mike is 5 years old. Mike's mother's age is 7 times his age. What is his mother's age?",
	"type":"maths",
	"answerone":"2",
	"optionsone":["foutry two","twenty five","thirty five","thirty"]
}
]